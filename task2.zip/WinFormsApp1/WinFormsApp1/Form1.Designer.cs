﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            finalimage = new PictureBox();
            usersfile = new Button();
            binarysave = new Button();
            decimalsave = new Button();
            ((System.ComponentModel.ISupportInitialize)finalimage).BeginInit();
            SuspendLayout();
            // 
            // finalimage
            // 
            finalimage.Location = new Point(63, 150);
            finalimage.Margin = new Padding(4, 5, 4, 5);
            finalimage.Name = "finalimage";
            finalimage.Size = new Size(594, 338);
            finalimage.TabIndex = 0;
            finalimage.TabStop = false;
            // 
            // usersfile
            // 
            usersfile.Location = new Point(63, 46);
            usersfile.Margin = new Padding(4, 5, 4, 5);
            usersfile.Name = "usersfile";
            usersfile.Size = new Size(190, 77);
            usersfile.TabIndex = 1;
            usersfile.Text = "Відкрити файл на пк";
            usersfile.UseVisualStyleBackColor = true;
            usersfile.Click += button1_Click;
            // 
            // binarysave
            // 
            binarysave.Location = new Point(261, 46);
            binarysave.Margin = new Padding(4, 5, 4, 5);
            binarysave.Name = "binarysave";
            binarysave.Size = new Size(190, 77);
            binarysave.TabIndex = 2;
            binarysave.Text = "Зеберегти у бінарному форматі";
            binarysave.UseVisualStyleBackColor = true;
            binarysave.Click += button2_Click;
            // 
            // decimalsave
            // 
            decimalsave.Location = new Point(459, 46);
            decimalsave.Margin = new Padding(4, 5, 4, 5);
            decimalsave.Name = "decimalsave";
            decimalsave.Size = new Size(198, 77);
            decimalsave.TabIndex = 3;
            decimalsave.Text = "Зберегти у десятковому форматі";
            decimalsave.UseVisualStyleBackColor = true;
            decimalsave.Click += button3_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1170, 917);
            Controls.Add(decimalsave);
            Controls.Add(binarysave);
            Controls.Add(usersfile);
            Controls.Add(finalimage);
            Margin = new Padding(4, 5, 4, 5);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)finalimage).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox finalimage;
        private Button usersfile;
        private Button binarysave;
        private Button decimalsave;
    }
}