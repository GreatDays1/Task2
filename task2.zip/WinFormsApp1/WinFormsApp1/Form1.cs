using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {

        private byte[] fileData;
        private const int PixelSize = 10;
        private const int MaxWidth = 800;
        private const int MaxHeight = 600;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "All files (*.*)|*.*";
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        fileData = File.ReadAllBytes(openFileDialog.FileName);
                        DrawFileData();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error: {ex.Message}");
                    }
                }
            }
        }

        private void DrawFileData()
        {
            int width = Math.Min(fileData.Length, MaxWidth / PixelSize);
            int height = (int)Math.Ceiling((double)fileData.Length / width);
            height = Math.Min(height, MaxHeight / PixelSize);

            Bitmap bitmap = new Bitmap(width * PixelSize, height * PixelSize);
            using (Graphics graphics = Graphics.FromImage(bitmap))
            {
                for (int i = 0; i < fileData.Length; i++)
                {
                    int x = (i % width) * PixelSize;
                    int y = (i / width) * PixelSize;

                    Color color = fileData[i] == 1 ? Color.Black : Color.White;
                    graphics.FillRectangle(new SolidBrush(color), x, y, PixelSize, PixelSize);
                }

                if (fileData.Length < width * height)
                {
                    for (int i = fileData.Length; i < width * height; i++)
                    {
                        int x = (i % width) * PixelSize;
                        int y = (i / width) * PixelSize;
                        graphics.FillRectangle(Brushes.Gray, x, y, PixelSize, PixelSize);
                    }
                }
            }

            finalimage.Image = bitmap;
        }


        private void button2_Click(object sender, EventArgs e)
        {
            if (fileData == null)
            {
                MessageBox.Show("No file data to save.");
                return;
            }

            using (SaveFileDialog saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.Filter = "Binary files (*.bin)|*.bin|All files (*.*)|*.*";
                saveFileDialog.RestoreDirectory = true;

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        File.WriteAllBytes(saveFileDialog.FileName, fileData);
                        MessageBox.Show("Binary file saved successfully.");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error: {ex.Message}");
                    }
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (fileData == null)
            {
                MessageBox.Show("No file data to save.");
                return;
            }

            using (SaveFileDialog saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
                saveFileDialog.RestoreDirectory = true;

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        string decimalData = string.Join(",", fileData);
                        File.WriteAllText(saveFileDialog.FileName, decimalData);
                        MessageBox.Show("Decimal file saved successfully.");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error: {ex.Message}");
                    }
                }
            }
        }
    }
}